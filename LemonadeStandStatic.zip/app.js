console.log('Lemonade Stand app is running!');
// Add your game logic here
